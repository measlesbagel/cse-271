
public interface iMovable {
	
	public void transfer(Transport t, Institution i);
	public void visit(Transport t, Institution i);
	
}
