public interface iHostPeople {
	
	public void add(Person p);
	public void remove(Person p);
	
}
