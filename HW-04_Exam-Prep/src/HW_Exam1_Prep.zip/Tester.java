import java.util.ArrayList;

public class Tester {

	static ArrayList<Transport> transport = new ArrayList<>();
	static ArrayList<Institution> institutions = new ArrayList<>();
	static ArrayList<Person> people = new ArrayList<>();
	
	public static void main(String[] args) {
		
	}

}
